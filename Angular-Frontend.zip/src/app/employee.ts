export class Employee 
{
  eid!:number;
  ename!:String;
  email!:String;
  mobile!:String;




}
